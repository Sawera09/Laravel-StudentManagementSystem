<footer>
    <p>&copy; 2024 Student Management System. All rights reserved.</p>
</footer>
<?php /**PATH C:\xampp\htdocs\student_management_system\resources\views/partials/footer.blade.php ENDPATH**/ ?>