

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Courses</h1>

    <!-- Add Course Button -->
    <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-primary mb-3">Add Course</a>

    <!-- Display Search Bar -->
    <form action="<?php echo e(route('courses.search')); ?>" method="GET" class="d-flex mb-3">
        <input class="form-control me-2" type="search" placeholder="Search Courses" name="query" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
    </form>

    <!-- Display Courses -->
    <table class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($course->title); ?></td>
                <td><?php echo e($course->description); ?></td>
                <td>
                    <!-- Edit and Delete Actions -->
                    <a href="<?php echo e(route('courses.edit', $course->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('courses.destroy', $course->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\student_management_system\resources\views/courses/index.blade.php ENDPATH**/ ?>