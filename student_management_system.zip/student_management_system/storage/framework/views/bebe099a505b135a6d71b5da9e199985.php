

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Students</h1>
    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary mb-3">Add Student</a>
    <!-- Display Search Bar -->
    <form action="<?php echo e(route('students.search')); ?>" method="GET" class="d-flex mb-3">
        <input class="form-control me-2" type="search" placeholder="Search Students" name="query" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
    </form>

    <!-- Display Students -->
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->email); ?></td>
                <td><?php echo e($student->phone); ?></td>
                <td>
                    <!-- Edit and Delete Actions -->
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\student_management_system\resources\views/students/index.blade.php ENDPATH**/ ?>