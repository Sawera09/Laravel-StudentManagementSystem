@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h1>Students</h1>
    <a href="{{ route('students.create') }}" class="btn btn-primary mb-3">Add Student</a>
    <!-- Display Search Bar -->
    <form action="{{ route('students.search') }}" method="GET" class="d-flex mb-3">
        <input class="form-control me-2" type="search" placeholder="Search Students" name="query" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
    </form>

    <!-- Display Students -->
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($students as $student)
            <tr>
                <td>{{ $student->name }}</td>
                <td>{{ $student->email }}</td>
                <td>{{ $student->phone }}</td>
                <td>
                    <!-- Edit and Delete Actions -->
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
