<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-success">
        <div class="container">
            <!-- Logo Section -->
            <a class="navbar-brand" href="/">
                <img src="{{ asset('images/WhatsApp Image 2024-12-19 at 21.36.08_1a2450d5.jpg') }}" alt="Logo" width="40" height="40" class="d-inline-block align-text-top">
                <span class="text-white fw-bold">STUDENT MANAGEMENT SYSTEM</span>
            </a>

            <!-- Mobile Toggle Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navigation Links -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="/home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="/students">Students</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="/courses">Courses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="/about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="/contact">Contact</a>
                    </li>
                    <!-- Authentication Links -->
                    @auth
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                {{ Auth::user()->name }}
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="{{ route('profile.edit') }}">Profile</a></li>
                                <li>
                                    <form action="{{ route('logout') }}" method="POST">
                                        @csrf
                                        <button class="dropdown-item" type="submit">Logout</button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    @else
                        <li class="nav-item"><a class="nav-link" href="{{ route('login') }}">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="{{ route('register') }}">Register</a></li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>
</header>
