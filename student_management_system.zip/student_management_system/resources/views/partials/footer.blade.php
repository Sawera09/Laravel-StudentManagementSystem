<footer>
    <p>&copy; 2024 Student Management System. All rights reserved.</p>
</footer>
