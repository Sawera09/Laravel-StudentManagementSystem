@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h1>Courses</h1>

    <!-- Add Course Button -->
    <a href="{{ route('courses.create') }}" class="btn btn-primary mb-3">Add Course</a>

    <!-- Display Search Bar -->
    <form action="{{ route('courses.search') }}" method="GET" class="d-flex mb-3">
        <input class="form-control me-2" type="search" placeholder="Search Courses" name="query" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
    </form>

    <!-- Display Courses -->
    <table class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($courses as $course)
            <tr>
                <td>{{ $course->title }}</td>
                <td>{{ $course->description }}</td>
                <td>
                    <!-- Edit and Delete Actions -->
                    <a href="{{ route('courses.edit', $course->id) }}" class="btn btn-warning btn-sm">Edit</a>
                    <form action="{{ route('courses.destroy', $course->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
