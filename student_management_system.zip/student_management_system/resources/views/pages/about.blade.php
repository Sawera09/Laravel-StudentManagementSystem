@extends('layouts.app')

@section('content')
    <div class="container mt-5">
        <h1 class="text-center mb-4">About Us</h1>
        
        <div class="row">
            <div class="col-md-6">
                <h3>Student Management System</h3>
                <p>
                    The Student Management System (SMS) is a platform designed to help administrators, teachers, and students manage student data efficiently. It provides features like adding, updating, and deleting student records, course management, and more.
                </p>
                <p>
                    Our system helps educational institutions manage their student data and make administrative tasks easier. Whether you are managing a small class or a large school, SMS simplifies student record-keeping, making it easy to track student performance, attendance, and other academic information.
                </p>
            </div>
            <div class="col-md-6">
                <h3>Our Mission</h3>
                <p>
                    Our mission is to provide an easy-to-use and reliable system for managing student data, enabling better academic tracking and management for educational institutions.
                </p>
                <h3>Our Vision</h3>
                <p>
                    We envision a future where educational institutions have streamlined processes for managing students, resulting in better academic outcomes and improved administration efficiency.
                </p>
            </div>
        </div>
    </div>
@endsection
