<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Course;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function index()
{
    $students = Student::all();
    return view('students.index', compact('students'));
}

public function create()
{
    $courses = Course::all();
    return view('students.create', compact('courses'));
}

public function store(Request $request)
{
    // Validate the incoming request
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|email|unique:students',
        'phone' => 'required',
        'image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        'courses' => 'required|array', // Ensure at least one course is selected
        'courses.*' => 'exists:courses,id' // Validate each selected course ID
    ]);

    // Handle Image Upload
    $imageName = null;
    if ($request->hasFile('image')) {
        $imageName = time() . '.' . $request->image->extension();
        $request->image->move(public_path('images'), $imageName);
    }

    // Create the Student
    $student = Student::create([
        'name' => $request->name,
        'email' => $request->email,
        'phone' => $request->phone,
        'image' => $imageName,
    ]);

    // Attach selected courses to the student
    $student->courses()->attach($request->courses);

    return redirect()->route('students.index')->with('success', 'Student added successfully.');
}

public function edit($id)
{
    $student = Student::findOrFail($id);
    $courses = Course::all();
    return view('students.edit', compact('student', 'courses'));
}

public function update(Request $request, $id)
{
    $student = Student::findOrFail($id);
    
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|email',
        'phone' => 'required',
        'image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    ]);
    
    $imageName = $student->image;
    if ($request->hasFile('image')) {
        $imageName = time() . '.' . $request->image->extension();
        $request->image->move(public_path('images'), $imageName);
    }

    $student->update([
        'name' => $request->name,
        'email' => $request->email,
        'phone' => $request->phone,
        'image' => $imageName,
    ]);

    if ($request->courses) {
        $student->courses()->sync($request->courses);
    }

    return redirect()->route('students.index')->with('success', 'Student updated successfully.');
}

public function destroy($id)
{
    $student = Student::findOrFail($id);
    $student->delete();
    return redirect()->route('students.index')->with('success', 'Student deleted successfully.');
}
public function search(Request $request)
{
    $search = $request->input('query');
    $students = Student::where('name', 'LIKE', "%{$search}%")
        ->orWhere('email', 'LIKE', "%{$search}%")
        ->orWhere('phone', 'LIKE', "%{$search}%")
        ->get();

    return view('students.index', compact('students'));
}


}
