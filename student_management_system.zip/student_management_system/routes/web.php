<?php
use App\Http\Controllers\HomeController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\CourseController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// HomeController routes
Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::get('/about', [HomeController::class, 'about'])->name('about');

// Contact routes
Route::get('/contact', [HomeController::class, 'contact'])->name('contact');  // Add this route for the contact form
Route::post('/contact', [HomeController::class, 'store'])->name('contact.store');  // This is for form submission

// Student routes
Route::get('/', [StudentController::class, 'index']);
Route::resource('students', StudentController::class);
Route::get('/search-students', [StudentController::class, 'search'])->name('students.search');
Route::get('/search-courses', [CourseController::class, 'search'])->name('courses.search');

// Course routes
Route::resource('courses', CourseController::class);

require __DIR__.'/auth.php';
use App\Http\Controllers\ProfileController;

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});
